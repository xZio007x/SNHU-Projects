// Final 2 Project.cpp : This file contains the 'main' function. Program execution begins and ends there.
//
#include <iostream>
#include <list>
#include<vector>
#include <string>
#include <conio.h>
#include <iomanip>
using namespace std;

class MyData {

    //Variables
    double openingAmount;
    double monthlyDeposit;
    double amountOfInterest;
    double closingBalance;
    int month;

public:  //Constructor
    MyData(double openingAmount, double monthlyDeposit, double amountOfInterest, int month, double closingBalance)
    {
        this->openingAmount = openingAmount;
        this->monthlyDeposit = monthlyDeposit;
        this->amountOfInterest = amountOfInterest;
        this->month = month;
        this->closingBalance = closingBalance;
    }
    //Public Get accessors. 
    double GetOpeningAmount() { return openingAmount; }
    double GetMonthlyDeposit() { return monthlyDeposit; }
    double GetTotal() { return (double)((double)openingAmount + (double)monthlyDeposit); }
    double GetamountOfInterest() { return amountOfInterest; }
    int GetMonth() { return month; }
    double GetClosingBalance() { return closingBalance; }
};
//Functions
void ClearScreen() { system("CLS"); }
int CalculateNumberOfMonths(int years) { return years * 12; }//How many months and iterations of calculations needed
double GetUserDoubleInput(string userMessage)
{
    bool userCompletedProcess = false;
    string userInput;
    double castedInput;
    while (userCompletedProcess == false)
    {
        cout << userMessage << endl;
        cin >> userInput;
        try
        {
            castedInput = std::stod(userInput);
            userCompletedProcess = true;
        }
        catch (exception e)
        {
            cout << "Process was invalid, Please Try Again." << endl;
        }
    }
    ClearScreen();
    return castedInput;
}
double GetUserIntInput(string userMessage)
{
    bool userCompletedProcess = false;
    string userInput;
    int castedInput;
    while (userCompletedProcess == false)
    {
        cout << userMessage << endl;
        cin >> userInput;
        try
        {
            castedInput = std::stoi(userInput);
            userCompletedProcess = true;
        }
        catch (exception e)
        {
            cout << "Process was invalid.  Please type in a integer value." << endl;
        }
    }
    ClearScreen();
    return castedInput;
}
void PressAnyKeyToContinue()
{
    cout << "Press Any Key To Continue." << endl;
    bool userHasPressedAKey = false;
    while (!userHasPressedAKey) { if (_kbhit()) { userHasPressedAKey = true; } }
}
bool CheckIfUserWantsToContinue()
{
    string userInput;
    bool userWantsToContinue = false;
    cout << "Would you like to continue with different investment values?" << endl;
    cout << "Press Y for Yes or N to quit program." << endl;
    cin >> userInput;
    if (userInput == "Y" || userInput == "y") {
        userWantsToContinue = true;
    }
    return userWantsToContinue;
}
string ConvertDoubleToString(double d) { return to_string(d); }
string ConvertIntToString(int i) { return to_string(i); }
double AddOpeningAndDepositedAmount(double openingAmount, double depositedAmount) { return openingAmount + depositedAmount; }
double CalculateInterest(double total, double interestRate)
{
    //(Opening Amount + Deposited Amount)* ((Interest Rate / 100) / 12)
    double endingAmount = total * ((interestRate / 100) / 12);
    return endingAmount;
}

double CalculateTotalEndingBalance(double total, double interest) { return total + interest; }
void PrintAllValues(vector<MyData> myData)
{
    for (int i = 0; i < myData.size(); i++)
    {
        cout << "Month " << setprecision(2) << fixed << myData[i].GetMonth() << "|";
        cout << "Starting Balance " << setprecision(2) << fixed << myData[i].GetOpeningAmount() << "|";
        cout << "Deposited Amount " << setprecision(2) << fixed << myData[i].GetMonthlyDeposit() << "|";
        cout << "Total " << setprecision(2) << fixed << myData[i].GetTotal() << "|";
        cout << "Interest " << setprecision(2) << fixed << myData[i].GetamountOfInterest() << "|";
        cout << "Closing Balance " << setprecision(2) << fixed << myData[i].GetClosingBalance() << "|" << endl;
    }
}
void PrintComparison(vector<MyData> listWithDeposit, vector<MyData>listWitOutDeposit)
{
    string option1Banner = "******************Viewing Yearly Totals With Monthly Deposit******************\n";
    string option2Banner = "******************Viewing Yearly Totals With Out Monthly Deposit******************\n";
    int numberOfYears = int(listWithDeposit.size() / 12);
    double initialInvestmentAmount = listWithDeposit[0].GetOpeningAmount();
    double amountOfInterest = 0;
    double runningTally = 0;
    cout << option1Banner << endl;
    for (int i = 11; i < listWithDeposit.size(); i += 12)//View Yearly Totals With Depoit
    {
        amountOfInterest = listWithDeposit[i].GetClosingBalance() - (50 * (listWithDeposit[i].GetMonth())) - runningTally - initialInvestmentAmount;
        cout << "Year " << setprecision(2) << fixed << listWithDeposit[i].GetMonth() / 12 << "|";
        //cout << "Starting Balance " << setprecision(2) << fixed << listWithDeposit[i].GetOpeningAmount() << "|";
         //cout << "Deposited Amount " << setprecision(2) << fixed << listWithDeposit[i].GetMonthlyDeposit() << "|";
         //cout << "Total " << setprecision(2) << fixed << listWithDeposit[i].GetTotal() << "|";
        // cout << "Total " << setprecision(2) << fixed << listWithDeposit[i].GetTotal() << "|";
        cout << "Closing Balance $" << setprecision(2) << fixed << listWithDeposit[i].GetClosingBalance() << "|";
        cout << "Year End Interest $" << setprecision(2) << fixed << amountOfInterest << "|" << endl;
        runningTally += amountOfInterest;
    }
    cout << endl << endl << option2Banner << endl;
    for (int i = 11; i < listWitOutDeposit.size(); i += 12)//Viewing Yearly Total Without Adding Deposits
    {
        cout << "Year " << setprecision(2) << fixed << listWitOutDeposit[i].GetMonth() / 12 << "|";
        // cout << "Starting Balance " << setprecision(2) << fixed << listWitOutDeposit[i].GetOpeningAmount() << "|";
        // cout << "Deposited Amount " << setprecision(2) << fixed << listWitOutDeposit[i].GetMonthlyDeposit() << "|";
         //cout << "Total " << setprecision(2) << fixed << listWitOutDeposit[i].GetTotal() << "|";
        double yearEndInterest = listWitOutDeposit[i].GetTotal() - listWitOutDeposit[i - 11].GetTotal();
        cout << "Closing Balance $" << setprecision(2) << fixed << listWitOutDeposit[i].GetClosingBalance() << "|";
        cout << "Year End Interest $" << setprecision(2) << fixed << yearEndInterest << "|" << endl;
        // cout << "Year End Interest " << setprecision(2) << fixed << listWitOutDeposit[i].GetamountOfInterest() << "|";
    }
}
bool DisplayMenu(vector<MyData> valuesWithDeposit, vector<MyData>valuesWitOutDeposit)
{
    string optionsMenu = "[1] View Totals With Monthly Deposit\n[2] View Total With Out Montly Deposit\n[3] View Comparison Of Monthly Deposit Vs No Montly Deposit By Year\n[4] Try Different Values To Compare\n[5] Quit The Program\n";
    string OptionsBanner = "******************Options Menu ******************\n";
    string option1Banner = "******************Viewing Totals With Monthly Deposit******************\n";
    string option2Banner = "******************Viewing Totals With Out Monthly Deposit******************\n";
    string option3Banner = "******************Viewing Comparison Of Monthly Deposit Vs No Montly Deposit******************\n";
    string option4Banner = "******************Try Different Values To Compare******************\n";
    string spacer = "-----------------------------------------------------------------\n";
    bool userWantsToQuitOrTryMoreValues = false;
    while (!userWantsToQuitOrTryMoreValues)//This method gives the user ways to view their data
    {
        ClearScreen();
        cout << OptionsBanner << endl;
        cout << optionsMenu;
        string userOption;
        cin >> userOption;
        if (userOption == "1") { cout << option1Banner << endl; PrintAllValues(valuesWithDeposit); PressAnyKeyToContinue(); }
        else if (userOption == "2") { cout << option2Banner << endl; PrintAllValues(valuesWitOutDeposit); PressAnyKeyToContinue(); }
        else if (userOption == "3") { PrintComparison(valuesWithDeposit, valuesWitOutDeposit); PressAnyKeyToContinue(); }
        else if (userOption == "4") { cout << "Going Back To Enter In More Values." << endl; PressAnyKeyToContinue(); ClearScreen(); break; }
        else if (userOption == "5") { return true; }
        else { cout << "Were sorry but there was an issue.  Please make a selection from the options provided and press Enter." << endl; PressAnyKeyToContinue(); }
    }
}//End Display Menu Method
int main()
{
    string bankingLogo = "              ****************** Welcome To Airgead Baking ******************\n";
    cout << bankingLogo << endl;
    PressAnyKeyToContinue();
    ClearScreen();
    cout.setf(ios::fixed);
    cout.setf(ios::showpoint);
    cout.precision(2);
    bool userWantsToContinue = true;
    while (userWantsToContinue)
    {
        vector<MyData>myDataWithMontlyDeposit;
        vector<MyData>myDataWithOutMontlyDeposit;
        double initialInvestmentAmount = GetUserDoubleInput("Please Enter Initial Investment Amount: ");
        double monthlyDeposit = GetUserDoubleInput("Please Enter Monthly Deposit: ");
        double AnnualInterest = GetUserDoubleInput("Please Enter Interest Compunded By Percentage: ");
        int numberOfYears = GetUserIntInput("Please Enter Number Of Years: ");
        int numberOfMonths = CalculateNumberOfMonths(numberOfYears);
        for (int i = 0; i < numberOfMonths; i++)
        {//Populate Number Of Months With Monthly Investment
            if (i == 0)//i=0 using starting values
            {
                double BeginningTotal = AddOpeningAndDepositedAmount(initialInvestmentAmount, monthlyDeposit);
                double CalculatedInterest = CalculateInterest(BeginningTotal, AnnualInterest);
                double EndingTotal = CalculateTotalEndingBalance(BeginningTotal, CalculatedInterest);
                myDataWithMontlyDeposit.push_back(MyData(initialInvestmentAmount, monthlyDeposit, CalculatedInterest, 1, EndingTotal));
            }
            else
            {//use previous vector's values
                double OpeningAmount = myDataWithMontlyDeposit[i - 1].GetClosingBalance();
                double beginningTotal = AddOpeningAndDepositedAmount(OpeningAmount, monthlyDeposit);
                double CalculatedInterest = CalculateInterest(beginningTotal, AnnualInterest);
                double EndingTotal = CalculateTotalEndingBalance(beginningTotal, CalculatedInterest);
                int month = myDataWithMontlyDeposit[i - 1].GetMonth() + 1;
                myDataWithMontlyDeposit.push_back(MyData(OpeningAmount, monthlyDeposit, CalculatedInterest, month, EndingTotal));
            }
        }//End Population Of Months With Deposit
        for (int i = 0; i < numberOfMonths; i++)
        {//Populate Number Of Months With Out Montly Investment
            if (i == 0)
            {
                double BeginningTotal = AddOpeningAndDepositedAmount(initialInvestmentAmount, 0);
                double CalculatedInterest = CalculateInterest(BeginningTotal, AnnualInterest);
                double EndingTotal = CalculateTotalEndingBalance(BeginningTotal, CalculatedInterest);
                myDataWithOutMontlyDeposit.push_back(MyData(initialInvestmentAmount, 0, CalculatedInterest, 1, EndingTotal));
            }
            else
            {//use previous vector's values
                double OpeningAmount = myDataWithOutMontlyDeposit[i - 1].GetClosingBalance();
                double beginningTotal = AddOpeningAndDepositedAmount(OpeningAmount, 0);
                double CalculatedInterest = CalculateInterest(beginningTotal, AnnualInterest);
                double EndingTotal = CalculateTotalEndingBalance(beginningTotal, CalculatedInterest);
                int month = myDataWithOutMontlyDeposit[i - 1].GetMonth() + 1;
                myDataWithOutMontlyDeposit.push_back(MyData(OpeningAmount, 0, CalculatedInterest, month, EndingTotal));
            }
        }//end of Populating Values Without Deposit
        if (DisplayMenu(myDataWithMontlyDeposit, myDataWithOutMontlyDeposit)) { userWantsToContinue = false; cout << "Thank You For Using Our Program, Have A Nice Day.\n" << endl; }
    }//End User Wants To Continue
}//End Main Method




// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
